import styled from "@emotion/styled"
// import Slider from "react-slick"

const Wrapper = styled.div`
    height: 200px;
    background-color: skyblue;
    font-size: 50px;
`

export default function LayoutHeader() {
   return <Wrapper>두상 영역</Wrapper>
}