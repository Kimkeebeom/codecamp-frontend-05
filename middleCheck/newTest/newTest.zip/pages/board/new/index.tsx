import BoardWrite from '../../../src/components/units/board/write/BoardWrite.container'

//등록(New) 페이지
export default function NewBoardWrite() {
    return <BoardWrite isEdit={false}/>
}