import { useState } from 'react'

import {Label, Name, Password, Title, Content, Address, 
    Register, Combined, Writer,Pwd, Spancombined, 
    Wrapper, MainTitle, WrapperHeader, Youtube, WrapperAddress
    ,Search,AddressText,WrapperAddressText, WrapperPhoto, 
    PhotoUpload, Click, SubTitle, SubContent, SubAddress, 
    SubYoutube, SubPhoto, Radio, SubRadio, NameError, PasswordError, 
    CntError, TitleError, Span} from '../../../styles/boardindex'

export default function boardPage() {
    
    const [writer, setWriter] = useState("")
    const [writererror, setWritererror] = useState("")

    const [pwd, setPwd] = useState("")
    const [pwderror, setPwderror] = useState("")

    const [title, setTitle] = useState("")
    const [titleerror, setTitleerror] = useState("")

    const [content, setContent] = useState("")
    const [contenterror, setContenterror] = useState("")

    function user(event){
        console.log(event.target.value)
        setWriter(event.target.value)
    }

    function password(event){
        setPwd(event.target.value)
    }

    function subject(event){
        console.log(event.target.value)
        setTitle(event.target.value)
    }

    function issue(event){
        console.log(event.target.value)
        setContent(event.target.value)
    }

    function regis(event){

        let check = true

        if(writer.length <= 0 === true){
            setWritererror("이름을 적어주세요")
            check = false
        } 
        if(pwd.length < 1 === true){
            setPwderror("비밀번호를 입력해주세요")
            check = false
        }
        if(title.length < 1 === true){
            setTitleerror("제목을 입력해주세요")
            check = false
        }
        if(content.length < 1 === true){
            setContenterror("내용을 입력해주세요")
            check = false
        }
    }

    return(
        <Wrapper>
            <WrapperHeader>
                <MainTitle>게시물 등록</MainTitle>
            </WrapperHeader>    
        
           <Spancombined>
                <Writer>작성자</Writer>
                <Pwd>비밀번호</Pwd>
            </Spancombined>
            <Combined>
                <Name type="text" onChange={user} placeholder='이름을 적어주세요' />
                <NameError>
                    <Span>{writererror}</Span>
                </NameError>
                <Password type="password" onChange={password} placeholder='비밀번호를 입력해주세요'/>
                <PasswordError>
                    <Span>{pwderror}</Span>
                </PasswordError>
            </Combined>
            

            <SubTitle>제목</SubTitle>
            <Title type="text" onChange={subject} placeholder='제목을 작성해주세요'/>
            <TitleError>
                <Span>{titleerror}</Span>
            </TitleError>

            <SubContent>내용</SubContent>
            <Content type="textarea" onChange={issue} placeholder='내용을 작성해주세요'/>
            <CntError>
                <Span>{contenterror}</Span>
            </CntError>

            <SubAddress>주소</SubAddress>
            <WrapperAddress>
                <Address type="address" placeholder='07250'/>
                <Search>
                    <Click>우편번호 검색</Click>
                </Search>
            </WrapperAddress>
            <WrapperAddressText>
                    <AddressText type="address"/>
                    <AddressText type="address"/>
            </WrapperAddressText>


            <SubYoutube>유튜브</SubYoutube>
            <Youtube type="text" placeholder='링크를 복사해주세요'/>

            <SubPhoto>사진 첨부</SubPhoto>
            <WrapperPhoto>
                <PhotoUpload>+</PhotoUpload>
                <PhotoUpload>+</PhotoUpload>
                <PhotoUpload>+</PhotoUpload>
            </WrapperPhoto>

            <SubRadio>메인 설정</SubRadio>
            <Radio>
            <input type="radio"/>유튜브
            <input type="radio"/>사진
            </Radio>

            <Register onClick={regis}>등록하기</Register>

        </Wrapper>
    )
}