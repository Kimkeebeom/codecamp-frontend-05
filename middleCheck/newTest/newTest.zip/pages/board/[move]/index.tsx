import BoardDetail from '../../../src/components/units/board/detail/BoardDetail.container'
// 게시물 상세페이지
export default function BoardDetailPage(){
    
    return (<BoardDetail/> )
}