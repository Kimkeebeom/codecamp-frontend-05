import BoardList from '../../../src/components/units/board/list/BoardList.container'

//게시물 목록(List) 페이지
export default function fetchBoardsPage(){
    return(<BoardList/> )
}
